
import pytest
import csv
from CommonFunctions.data_reader import read_test_data
from pages.workitem_api import call_workitem_api
from CommonFunctions.logger import get_logger

logger = get_logger(__name__)
test_data = read_test_data("data/input_data.csv", batch_size=1)

@pytest.mark.parametrize("payload", test_data)
def test_workitem_api(payload, access_token):  # uses fixture now
    logger.info(f"Sending payload: {payload}")
    
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    response = call_workitem_api(payload, headers)
    logger.info(f"Received response: {response.status_code} - {response.text}")

    try:
        response_json = response.json()
    except Exception as e:
        logger.error(f"Invalid JSON response: {response.text}")
        pytest.fail("Response is not valid JSON")

    assert "status" in response_json, "Missing 'status' in response"
    assert "message" in response_json, "Missing 'message' in response"

    if response_json["status"] != "SUCCESS":
        logger.error(f"API returned error: {response_json['message']}")
        pytest.fail(f"API returned failure status: {response_json['status']}")

    with open("output/response_output.csv", "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([payload, response.status_code, response_json.get("message", "")])
