
import subprocess
import requests
import os
from CommonFunctions.proxy_setup import set_proxy

set_proxy()

def get_jwt_token():
    return "mocked_username"

def invoke_api(method, url, headers=None, payload=None, proxies=None):
    response = requests.request(
        method=method,
        url=url,
        headers=headers,
        json=payload,
        proxies=proxies,
        timeout=30,
        verify=False
    )
    return response

def get_oauth_token(username):
    url = "https://your.auth.api/token"
    payload = {"username": username}
    headers = {"Content-Type": "application/json"}
    proxies = {
        "http": os.environ.get("HTTP_PROXY"),
        "https": os.environ.get("HTTPS_PROXY")
    }
    response = invoke_api("POST", url, headers=headers, payload=payload, proxies=proxies)
    return response.json().get("access_token", "mocked_access_token")
