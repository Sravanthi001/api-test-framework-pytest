
import csv
import os

def read_dat_file(file_path, batch_size=1):
    test_data = []
    with open(file_path, "r") as file:
        reader = csv.DictReader(file, delimiter="|")
        batch = []
        for row in reader:
            batch.append(dict(row))
            if len(batch) == batch_size:
                test_data.append(batch if batch_size > 1 else batch[0])
                batch = []
        if batch:
            test_data.append(batch if batch_size > 1 else batch[0])
    return test_data

def read_csv_file(file_path, batch_size=1):
    test_data = []
    with open(file_path, "r") as file:
        reader = csv.DictReader(file)
        batch = []
        for row in reader:
            batch.append(dict(row))
            if len(batch) == batch_size:
                test_data.append(batch if batch_size > 1 else batch[0])
                batch = []
        if batch:
            test_data.append(batch if batch_size > 1 else batch[0])
    return test_data

def read_test_data(file_path, batch_size=1):
    test_data = []
    _, ext = os.path.splitext(file_path)
    delimiter = "|" if ext == ".dat" else ","
    with open(file_path, "r") as file:
        reader = csv.DictReader(file, delimiter=delimiter)
        batch = []
        for row in reader:
            batch.append(dict(row))
            if len(batch) == batch_size:
                test_data.append(batch if batch_size > 1 else batch[0])
                batch = []
        if batch:
            test_data.append(batch if batch_size > 1 else batch[0])
    return test_data
