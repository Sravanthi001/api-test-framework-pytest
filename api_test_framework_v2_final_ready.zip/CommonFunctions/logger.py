
import logging
import os
from datetime import datetime

def get_logger(name):
    log_dir = "output/logs"
    os.makedirs(log_dir, exist_ok=True)

    timestamp = "2025-04-21_18-45-55"
    log_file = os.path.join(log_dir, f"test_execution_{timestamp}.log")

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    if not logger.handlers:
        fh = logging.FileHandler(log_file, mode='a')
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    return logger
