
import os

def set_proxy():
    os.environ["HTTP_PROXY"] = "http://your.proxy.server:port"
    os.environ["HTTPS_PROXY"] = "http://your.proxy.server:port"

set_proxy()
