
# API Test Framework (Pytest-based)

## Proxy Setup
Set proxy in `CommonFunctions/proxy_setup.py`.

## Install Requirements
```bash
pip install --proxy=http://your.proxy.server:port -r requirements.txt
```

## Run Tests
```bash
pytest
```

## View HTML Report
Open `output/report.html` in a browser.
