
import os
import requests

def call_workitem_api(payload, headers):
    url = "https://your.api.com/workitem"
    proxy_url = os.environ.get("HTTP_PROXY")
    proxies = {"http": proxy_url, "https": proxy_url}
    response = requests.post(url, json=payload, headers=headers, proxies=proxies, verify=False)
    return response
